package cn.st.lab1;

import static org.junit.Assert.*;

import org.junit.*;

public class testTriangle {
	
	Triangle t;
	@Before
	public void setUp(){
		t = new Triangle();
	}
	
	@Test
	public void testIsEquilateral() {
		assertEquals("testIsEquilateral", true, t.isEquilateral(6,6,6));
	}
	@Test
	public void testIsIsosceles() {
		assertEquals("testIsIsosceles", true, t.isIsosceles(5,6,6));
	}
	@Test
	public void testIsTriangle() {
		assertEquals("testIsTriangle", true, t.isTriangle(5,6,7));
	}
	@Test
	public void testTriangle() {
		t.Triangle(3, 4, 5);
		t.Triangle(3, 4, 4);
		t.Triangle(4, 4, 4);
		t.Triangle(1, 1, 5);
	}
}
