package cn.st.lab1;

public class Triangle {
	public static boolean isTriangle(int a, int b, int c) {
		if(a+b>c && a+c>b && b+c>a && Math.abs(a-b)<c && 
				Math.abs(a-c)<b && Math.abs(b-c)<a && a>0 && b>0 && c>0) {
			return true;
		}
		else {
			return false;
		}
	}
	public static boolean isEquilateral(int a, int b, int c) {
		if(isTriangle(a,b,c)) {
			if(a == b && a == c) {
				return true;
			}
		}
		return false;
	}
	public static boolean isIsosceles(int a, int b, int c) {
		if(isTriangle(a,b,c)) {
			if(a == b || a == c || b == c) {
				return true;
			}
		}
		return false;
	}
	
	public static void Triangle (int a, int b, int c) {
		if(isTriangle(a,b,c)) {	//输出以下内容，则为三角形
			if(isEquilateral(a,b,c)) {
				System.out.println("Equilateral");
			} //如果是等边，只输出等边，不输出等腰
			else if(isIsosceles(a,b,c)) {
				System.out.println("Isosceles");
			}
			else {
				System.out.println("Scalene");
			}
		}
		else {
			System.out.println("NotATriangle");
		}
	}
}
